import { NavLink } from 'react-router-dom';
import {
  Activity,
  BookOpen,
  ChevronDown,
  Clock,
  Folder,
  Headphones,
  Lock,
  Settings,
  Users,
} from 'lucide-react';

interface Props {
  isOpen: boolean;
}


export default function Sidebar({ isOpen }: Props) {
  return (
    <aside className={`guru-sidebar ${isOpen ? 'open' : 'closed'}`}>
      <div className="guru-sidebar-tools">
        <button type="button" aria-label="Back">‹</button>
        <button type="button" aria-label="Search">⌕</button>
      </div>

      <div className="guru-folder-list">
        <NavLink to="/admin/dashboard" className="guru-folder-item">
          <Folder size={16} />
          <span>Dashboard</span>
        </NavLink>
        <NavLink to="/admin/users" className="guru-folder-item">
          <Users size={16} />
          <span>Users</span>
        </NavLink>
        <NavLink to="/admin/profile" className="guru-folder-item">
          <Folder size={16} />
          <span>Profile</span>
        </NavLink>
      </div>

      <div className="guru-sidebar-card compact">
        <Clock size={30} />
        <div>
          <strong>System</strong>
          <span>Monitor Platform</span>
        </div>
      </div>
    </aside>
  );
}
