import { NavLink } from 'react-router-dom';
import { LayoutDashboard, UserRound, Users, Sparkles } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/admin/dashboard', icon: LayoutDashboard },
  { label: 'Users', path: '/admin/users', icon: Users },
  { label: 'Profile', path: '/admin/profile', icon: UserRound },
];

export default function Sidebar() {
  return (
    <aside className="sidebar app-sidebar admin-sidebar">
      <div className="brand app-brand">
        <div className="brand-mark">B</div>
        <div>
          <h1>BotUI Admin</h1>
          <p>Mission Control</p>
        </div>
      </div>

      <div className="sidebar-section-label">Workspace</div>

      <nav className="nav-list">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink key={item.label} to={item.path} className="nav-link">
              <Icon size={18} />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      <div className="sidebar-upgrade-card">
        <Sparkles size={18} />
        <strong>Admin System</strong>
        <span>Manage users, roles, and platform access.</span>
      </div>

      <div className="sidebar-footer">
        <span>React + FastAPI</span>
        <small>Modular architecture</small>
      </div>
    </aside>
  );
}
