import { Bot, ShieldCheck, UserPlus, Users, Activity, Database } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AdminDashboard() {
  return (
    <div className="dashboard-page">
      <section className="page-header hero-header admin-hero">
        <div>
          <span className="page-kicker">Admin only</span>
          <h1>Admin Dashboard</h1>
          <p>Manage users, roles, access control, and future AI agent resources from one clean workspace.</p>
        </div>
        <div className="hero-actions">
          <Link className="admin-btn admin-btn-light" to="/admin/users">
            View Users
          </Link>
          <Link className="admin-btn admin-btn-dark" to="/admin/users/new">
            <UserPlus size={17} />
            Add User
          </Link>
        </div>
      </section>

      <div className="metric-grid">
        <div className="metric-card">
          <div className="metric-icon"><Users size={20} /></div>
          <span>Total Users</span>
          <strong>Manage</strong>
          <p>View, edit, activate, and deactivate accounts.</p>
        </div>
        <div className="metric-card">
          <div className="metric-icon"><ShieldCheck size={20} /></div>
          <span>Security</span>
          <strong>Role Guarded</strong>
          <p>Admin routes are protected by role-based access.</p>
        </div>
        <div className="metric-card">
          <div className="metric-icon"><Activity size={20} /></div>
          <span>System</span>
          <strong>Healthy</strong>
          <p>Frontend structure is ready for scalable modules.</p>
        </div>
        <div className="metric-card">
          <div className="metric-icon"><Database size={20} /></div>
          <span>Data</span>
          <strong>API Ready</strong>
          <p>Connected through the shared API client layer.</p>
        </div>
      </div>

      <div className="card-grid">
        <div className="stat-card feature-card">
          <Users />
          <h3>User Management</h3>
          <p>Promote users to customers, deactivate accounts, and manage platform access.</p>
          <Link to="/admin/users">Open module</Link>
        </div>

        <div className="stat-card feature-card">
          <ShieldCheck />
          <h3>Security Control</h3>
          <p>Keep admin, customer, and user workspaces separated with role-based guards.</p>
          <Link to="/admin/profile">Manage profile</Link>
        </div>

        <div className="stat-card feature-card">
          <Bot />
          <h3>Agent Setup</h3>
          <p>Future home for global agent templates, system prompts, and RAG resources.</p>
          <button className="admin-btn" type="button">Coming Soon</button>
        </div>
      </div>
    </div>
  );
}
