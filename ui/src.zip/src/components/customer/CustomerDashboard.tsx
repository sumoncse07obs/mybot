import { Bot, Database, FileText, MessageSquare, Settings, UploadCloud } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function CustomerDashboard() {
  return (
    <div className="dashboard-page">
      <section className="page-header hero-header customer-hero">
        <div>
          <span className="page-kicker">Customer only</span>
          <h1>Customer Dashboard</h1>
          <p>Manage your AI workspace, customer resources, and chatbot knowledge from a clean control center.</p>
        </div>
        <div className="hero-actions">
          <Link className="admin-btn admin-btn-light" to="/customer/profile">
            Profile
          </Link>
          <button className="admin-btn admin-btn-dark" type="button">
            <UploadCloud size={17} />
            Upload Resource
          </button>
        </div>
      </section>

      <div className="metric-grid">
        <div className="metric-card">
          <div className="metric-icon"><FileText size={20} /></div>
          <span>Resources</span>
          <strong>Ready</strong>
          <p>Prepare documents, URLs, and business knowledge.</p>
        </div>
        <div className="metric-card">
          <div className="metric-icon"><Database size={20} /></div>
          <span>Knowledge Base</span>
          <strong>Indexed</strong>
          <p>Future area for chunks, embeddings, and content.</p>
        </div>
        <div className="metric-card">
          <div className="metric-icon"><Bot size={20} /></div>
          <span>Agents</span>
          <strong>Configure</strong>
          <p>Create customer-specific chatbot behavior.</p>
        </div>
        <div className="metric-card">
          <div className="metric-icon"><MessageSquare size={20} /></div>
          <span>Chat</span>
          <strong>Test</strong>
          <p>Preview chatbot answers before publishing.</p>
        </div>
      </div>

      <div className="card-grid">
        <div className="stat-card feature-card">
          <FileText />
          <h3>Resources</h3>
          <p>Upload documents, URLs, and business knowledge for your RAG chatbot.</p>
          <button className="admin-btn" type="button">Coming Soon</button>
        </div>

        <div className="stat-card feature-card">
          <Database />
          <h3>Knowledge Base</h3>
          <p>Future area for chunks, embeddings, and indexed customer content.</p>
          <button className="admin-btn" type="button">Coming Soon</button>
        </div>

        <div className="stat-card feature-card">
          <Settings />
          <h3>Agent Settings</h3>
          <p>Create and configure customer-specific chatbot agents.</p>
          <Link to="/customer/profile">Open settings</Link>
        </div>
      </div>
    </div>
  );
}
