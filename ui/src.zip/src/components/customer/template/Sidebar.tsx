import { NavLink } from 'react-router-dom';
import { Bot, LayoutDashboard, UserRound, Sparkles } from 'lucide-react';

const navItems = [
  { label: 'Dashboard', path: '/customer/dashboard', icon: LayoutDashboard },
  { label: 'Agents', path: '/customer/dashboard', icon: Bot },
  { label: 'Profile', path: '/customer/profile', icon: UserRound },
];

export default function Sidebar() {
  return (
    <aside className="sidebar app-sidebar customer-sidebar">
      <div className="brand app-brand">
        <div className="brand-mark">B</div>
        <div>
          <h1>BotUI</h1>
          <p>Customer Workspace</p>
        </div>
      </div>

      <div className="sidebar-section-label">Main Menu</div>

      <nav className="nav-list">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink key={item.label} to={item.path} className="nav-link">
              <Icon size={18} />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      <div className="sidebar-upgrade-card">
        <Sparkles size={18} />
        <strong>AI Workspace</strong>
        <span>Build and manage customer chatbot knowledge.</span>
      </div>

      <div className="sidebar-footer">
        <span>BotUI Customer</span>
        <small>React + FastAPI</small>
      </div>
    </aside>
  );
}
