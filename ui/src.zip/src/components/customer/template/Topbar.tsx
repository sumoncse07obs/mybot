import { LogOut, Search, UserRound } from 'lucide-react';
import type { AuthUser } from '@/types';

interface Props {
  user: AuthUser | null;
  onLogout: () => void;
}

export default function Topbar({ user, onLogout }: Props) {
  const fullName = `${user?.first_name || ''} ${user?.last_name || ''}`.trim() || user?.email || 'Unknown user';
  const initials = fullName
    .split(' ')
    .map((part) => part[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <header className="topbar app-topbar">
      <div className="topbar-title-block">
        <p className="eyebrow">Customer Workspace</p>
        <h2>Welcome back, {fullName}</h2>
      </div>

      <div className="topbar-search">
        <Search size={17} />
        <span>Search workspace...</span>
      </div>

      <div className="topbar-actions">
        <span className={`role-pill role-${user?.role}`}>
          <UserRound size={14} />
          {user?.role || 'customer'}
        </span>
        <div className="user-avatar">{initials || 'U'}</div>
        <button className="logout-btn" onClick={onLogout}>
          <LogOut size={18} />
          Logout
        </button>
      </div>
    </header>
  );
}
